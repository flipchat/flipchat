CREATE VIEW view1 AS
SELECT product.cat_id,
    avg(((product.price)::numeric)::double precision) AS avgprice
   FROM product
  GROUP BY product.cat_id