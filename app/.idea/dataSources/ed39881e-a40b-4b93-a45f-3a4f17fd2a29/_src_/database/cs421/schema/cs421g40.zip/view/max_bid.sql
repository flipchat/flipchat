CREATE VIEW max_bid AS
SELECT bid.p_id,
    max((bid.price)::numeric) AS price
   FROM bid
  GROUP BY bid.p_id