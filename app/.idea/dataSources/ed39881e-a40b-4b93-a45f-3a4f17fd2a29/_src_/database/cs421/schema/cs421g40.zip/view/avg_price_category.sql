CREATE VIEW avg_price_category AS
SELECT product.cat_id,
    avg((product.price)::numeric) AS avg_price
   FROM product
  GROUP BY product.cat_id